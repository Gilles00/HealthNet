Navigate to cheney.csh.rit.edu:8000/login to see the deployed site preview.
