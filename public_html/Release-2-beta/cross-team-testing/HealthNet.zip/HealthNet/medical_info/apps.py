from django.apps import AppConfig


class MedicalInfoConfig(AppConfig):
    name = 'medical_info'
