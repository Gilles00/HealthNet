from django import forms
from django.db import models
from .models import Prescription, Test
from registration.models import Patient

class PrescriptionForm(forms.ModelForm):
    class Meta:
        model = Prescription
        fields = ['name', 'dosage_info', 'patient']

class AddTestForm(forms.ModelForm):
    class Meta:
        model = Test
        exclude = ['result', 'comments', 'patient']

class ReleaseTestForm(forms.ModelForm):
    class Meta:
        model = Test
        exclude = ['name', 'date', 'patient']

class MedicalInfoForm(forms.Form):
    height = forms.FloatField(help_text='Enter your height in feet')
    weight = forms.FloatField(help_text='Enter your weight in pounds')

