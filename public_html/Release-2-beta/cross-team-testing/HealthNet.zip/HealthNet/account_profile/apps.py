from django.apps import AppConfig


class AccountProfileConfig(AppConfig):
    name = 'account_profile'
