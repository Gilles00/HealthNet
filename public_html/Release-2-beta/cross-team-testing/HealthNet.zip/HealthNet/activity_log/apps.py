from django.apps import AppConfig


class ActivityLogConfig(AppConfig):
    name = 'activity_log'
